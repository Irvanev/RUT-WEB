module.exports = require('@gravity-ui/prettier-config');
