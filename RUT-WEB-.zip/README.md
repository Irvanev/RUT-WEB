<h1 align="center">Gravity UI example</h1>

This is a blank README file that you can customize at your needs.\
Describe your project, how it works and how to contribute to it.

# 🚀 Available Scripts

In the project directory, you can run:

## ⚡️ start

```
npm start
```

or

```
yarn start
```

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## 🧪 test

```
npm test
```

or

```
yarn test
```

Launches the test runner in the interactive watch mode.

## 🦾 build

```
npm build
```

or

```
yarn build
```

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.

## 🧶 lint

```
npm lint
```

or

```
yarn lint
```

# 📖 Learn More

You can learn more in the [Create React App documentation](https://create-react-app.dev/docs/getting-started/).

To learn React, check out the [React documentation](https://react.dev/).

#

<p align="center">Bootstrapped with Create React App.</p>
